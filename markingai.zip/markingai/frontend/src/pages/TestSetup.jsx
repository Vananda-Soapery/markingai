import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowRight, FileText, Users } from 'lucide-react'
import Layout from '../components/Layout'
import StepIndicator from '../components/StepIndicator'
import ErrorBanner from '../components/ErrorBanner'
import DropZone from '../components/DropZone'
import { sessionsApi, getErrorMessage } from '../api/client'

const GRADES = ['R', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']

export default function TestSetup() {
  const navigate = useNavigate()

  const [subject, setSubject] = useState('')
  const [grade, setGrade] = useState('')
  const [testName, setTestName] = useState('')
  const [totalMarks, setTotalMarks] = useState('')
  const [memoFile, setMemoFile] = useState(null)
  const [classListFile, setClassListFile] = useState(null)

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const canContinue = subject.trim() && grade && Number(totalMarks) > 0 && memoFile

  const handleSubmit = async () => {
    setError(null)
    if (!canContinue) {
      setError('Please fill in Subject, Grade, Total Marks, and upload the memo before continuing.')
      return
    }
    setLoading(true)
    try {
      const { data: session } = await sessionsApi.create({
        subject: subject.trim(),
        grade,
        totalMarks: Number(totalMarks),
        testName: testName.trim() || 'Test',
      })

      await sessionsApi.uploadMemo(session.session_id, memoFile)

      if (classListFile) {
        await sessionsApi.uploadClassList(session.session_id, classListFile)
      }

      navigate(`/upload/${session.session_id}`)
    } catch (e) {
      setError(getErrorMessage(e))
    } finally {
      setLoading(false)
    }
  }

  return (
    <Layout>
      <StepIndicator currentStep={1} />

      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-slate-900 sm:text-3xl">Let's set up your test</h2>
        <p className="mt-1 text-slate-500">Tell us about the test, then upload the memo teachers use to mark it.</p>
      </div>

      <ErrorBanner message={error} onDismiss={() => setError(null)} />

      <div className="card space-y-6">
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Subject</label>
            <input
              type="text"
              className="input-field"
              placeholder="e.g. Mathematics"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Grade</label>
            <select className="input-field" value={grade} onChange={(e) => setGrade(e.target.value)}>
              <option value="">Select grade...</option>
              {GRADES.map((g) => (
                <option key={g} value={g}>
                  Grade {g}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Test Name (optional)</label>
            <input
              type="text"
              className="input-field"
              placeholder="e.g. Term 2 Test"
              value={testName}
              onChange={(e) => setTestName(e.target.value)}
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700">Total Marks</label>
            <input
              type="number"
              min="1"
              className="input-field"
              placeholder="e.g. 50"
              value={totalMarks}
              onChange={(e) => setTotalMarks(e.target.value)}
            />
          </div>
        </div>

        <div>
          <label className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-700">
            <FileText size={16} /> Memo (PDF) <span className="font-normal text-red-500">*required</span>
          </label>
          <DropZone
            accept=".pdf"
            label={memoFile ? 'Memo selected' : 'Drop the memo PDF here, or tap to browse'}
            hint="This is the marking guideline the AI will grade against"
            successFilename={memoFile?.name}
            onFiles={(files) => setMemoFile(files[0])}
          />
        </div>

        <div>
          <label className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-700">
            <Users size={16} /> Class List (Excel/CSV) <span className="font-normal text-slate-400">optional</span>
          </label>
          <DropZone
            accept=".xlsx,.xls,.csv"
            compact
            label={classListFile ? 'Class list selected' : 'Drop your class list here, or tap to browse'}
            hint="Used to match names on papers and flag absent students"
            successFilename={classListFile?.name}
            onFiles={(files) => setClassListFile(files[0])}
          />
        </div>
      </div>

      <div className="mt-8 flex justify-end">
        <button className="btn-primary w-full sm:w-auto" onClick={handleSubmit} disabled={loading}>
          {loading ? 'Setting up...' : 'Continue to Upload Papers'}
          {!loading && <ArrowRight size={20} />}
        </button>
      </div>
    </Layout>
  )
}
