import { useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Loader2, CheckCircle2, XCircle, AlertCircle, Sparkles } from 'lucide-react'
import Layout from '../components/Layout'
import StepIndicator from '../components/StepIndicator'
import ErrorBanner from '../components/ErrorBanner'
import { sessionsApi, getErrorMessage } from '../api/client'

const STATUS_ICON = {
  done: <CheckCircle2 size={16} className="text-green-600" />,
  failed: <XCircle size={16} className="text-red-500" />,
  needs_review: <AlertCircle size={16} className="text-amber-500" />,
  processing: <Loader2 size={16} className="animate-spin text-brand-500" />,
  pending: <div className="h-4 w-4 rounded-full border-2 border-slate-200" />,
}

export default function Processing() {
  const { sessionId } = useParams()
  const navigate = useNavigate()
  const [progress, setProgress] = useState(null)
  const [error, setError] = useState(null)
  const pollRef = useRef(null)

  useEffect(() => {
    const poll = async () => {
      try {
        const { data } = await sessionsApi.getProgress(sessionId)
        setProgress(data)

        if (data.status === 'completed') {
          clearInterval(pollRef.current)
          setTimeout(() => navigate(`/results/${sessionId}`), 900)
        } else if (data.status === 'failed') {
          clearInterval(pollRef.current)
          setError('Processing failed. Please check your OpenAI API key configuration and try again.')
        }
      } catch (e) {
        setError(getErrorMessage(e))
        clearInterval(pollRef.current)
      }
    }

    poll()
    pollRef.current = setInterval(poll, 1500)
    return () => clearInterval(pollRef.current)
  }, [sessionId, navigate])

  const pct = progress && progress.total_papers > 0 ? Math.round((progress.processed_papers / progress.total_papers) * 100) : 0

  return (
    <Layout>
      <StepIndicator currentStep={3} />

      <div className="mb-8 text-center">
        <h2 className="text-2xl font-bold text-slate-900 sm:text-3xl">AI is marking the papers</h2>
        <p className="mt-1 text-slate-500">This usually takes a few seconds per paper. Feel free to wait here.</p>
      </div>

      <ErrorBanner message={error} onDismiss={() => setError(null)} />

      <div className="card mb-6">
        <div className="mb-4 flex items-center justify-center gap-2">
          <Sparkles className="text-brand-500 animate-pulse-slow" size={22} />
          <p className="text-lg font-semibold text-slate-800">
            {progress
              ? progress.status === 'completed'
                ? 'All papers marked!'
                : progress.current_filename
                ? `Marking "${progress.current_filename}"...`
                : 'Getting started...'
              : 'Connecting...'}
          </p>
        </div>

        <div className="mb-2 h-4 w-full overflow-hidden rounded-full bg-slate-100">
          <div
            className="h-full rounded-full bg-gradient-to-r from-brand-500 to-brand-600 transition-all duration-500"
            style={{ width: `${pct}%` }}
          />
        </div>
        <p className="text-center text-sm font-medium text-slate-500">
          {progress ? `Marking paper ${Math.min(progress.processed_papers + 1, progress.total_papers)} of ${progress.total_papers}` : ''}
          {progress?.status === 'completed' && ` — Done!`}
        </p>
      </div>

      {progress?.papers?.length > 0 && (
        <div className="card">
          <h3 className="mb-3 text-sm font-semibold text-slate-500">Paper status</h3>
          <ul className="max-h-80 divide-y divide-slate-100 overflow-y-auto">
            {progress.papers.map((p) => (
              <li key={p.paper_id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                <span className="truncate text-slate-700">{p.filename}</span>
                <span className="flex shrink-0 items-center gap-2">
                  {p.status === 'done' && p.percentage != null && (
                    <span className="font-semibold text-slate-500">{p.percentage}%</span>
                  )}
                  {STATUS_ICON[p.status] || STATUS_ICON.pending}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </Layout>
  )
}
