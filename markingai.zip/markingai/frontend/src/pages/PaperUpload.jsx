import { useEffect, useState, useCallback } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ArrowRight, ArrowLeft, Trash2, FileImage, FileText as FileTextIcon } from 'lucide-react'
import Layout from '../components/Layout'
import StepIndicator from '../components/StepIndicator'
import ErrorBanner from '../components/ErrorBanner'
import DropZone from '../components/DropZone'
import { sessionsApi, getErrorMessage, isSubscriptionRequiredError } from '../api/client'

export default function PaperUpload() {
  const { sessionId } = useParams()
  const navigate = useNavigate()

  const [sessionInfo, setSessionInfo] = useState(null)
  const [papers, setPapers] = useState([])
  const [uploading, setUploading] = useState(false)
  const [uploadPct, setUploadPct] = useState(0)
  const [error, setError] = useState(null)
  const [rejectedFiles, setRejectedFiles] = useState([])

  const loadSession = useCallback(async () => {
    try {
      const { data } = await sessionsApi.get(sessionId)
      setSessionInfo(data)
      const { data: paperData } = await sessionsApi.listPapers(sessionId)
      setPapers(paperData.papers)
    } catch (e) {
      setError(getErrorMessage(e))
    }
  }, [sessionId])

  useEffect(() => {
    loadSession()
  }, [loadSession])

  const handleFiles = async (files) => {
    setError(null)
    setRejectedFiles([])
    setUploading(true)
    setUploadPct(0)
    try {
      const { data } = await sessionsApi.uploadPapers(sessionId, files, (evt) => {
        if (evt.total) setUploadPct(Math.round((evt.loaded / evt.total) * 100))
      })
      if (data.rejected?.length) setRejectedFiles(data.rejected)
      await loadSession()
    } catch (e) {
      setError(getErrorMessage(e))
    } finally {
      setUploading(false)
    }
  }

  const handleRemove = async (paperId) => {
    try {
      await sessionsApi.removePaper(sessionId, paperId)
      setPapers((prev) => prev.filter((p) => p.paper_id !== paperId))
    } catch (e) {
      setError(getErrorMessage(e))
    }
  }

  const handleContinue = async () => {
    if (papers.length === 0) {
      setError('Please upload at least one student paper before continuing.')
      return
    }
    try {
      await sessionsApi.startProcessing(sessionId)
      navigate(`/processing/${sessionId}`)
    } catch (e) {
      if (isSubscriptionRequiredError(e)) {
        navigate('/subscribe', { state: { returnTo: `/upload/${sessionId}` } })
        return
      }
      setError(getErrorMessage(e))
    }
  }

  return (
    <Layout>
      <StepIndicator currentStep={2} />

      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-slate-900 sm:text-3xl">Upload student papers</h2>
        <p className="mt-1 text-slate-500">
          {sessionInfo
            ? `${sessionInfo.subject} · Grade ${sessionInfo.grade} · ${sessionInfo.total_marks} marks`
            : 'Loading test details...'}
        </p>
      </div>

      <ErrorBanner message={error} onDismiss={() => setError(null)} />

      {rejectedFiles.length > 0 && (
        <div className="mb-6 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
          <p className="mb-1 font-semibold">Some files couldn't be uploaded:</p>
          <ul className="list-inside list-disc space-y-0.5">
            {rejectedFiles.map((r, i) => (
              <li key={i}>
                {r.filename}: {r.reason}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="card mb-6">
        <DropZone
          accept=".pdf,.png,.jpg,.jpeg,.webp"
          multiple
          label="Drag & drop scanned papers here, or tap to browse"
          hint="Upload images or PDFs — multiple files at once, up to 25MB each"
          onFiles={handleFiles}
        />
        {uploading && (
          <div className="mt-4">
            <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
              <div className="h-full rounded-full bg-brand-600 transition-all" style={{ width: `${uploadPct}%` }} />
            </div>
            <p className="mt-1 text-center text-xs text-slate-400">Uploading... {uploadPct}%</p>
          </div>
        )}
      </div>

      {papers.length > 0 && (
        <div className="card mb-6">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-semibold text-slate-800">
              {papers.length} paper{papers.length !== 1 ? 's' : ''} ready
            </h3>
          </div>
          <ul className="divide-y divide-slate-100">
            {papers.map((p) => (
              <li key={p.paper_id} className="flex items-center justify-between gap-3 py-3">
                <div className="flex min-w-0 items-center gap-3">
                  {p.filename.toLowerCase().endsWith('.pdf') ? (
                    <FileTextIcon size={20} className="shrink-0 text-brand-500" />
                  ) : (
                    <FileImage size={20} className="shrink-0 text-brand-500" />
                  )}
                  <span className="truncate text-sm font-medium text-slate-700">{p.filename}</span>
                </div>
                <button
                  onClick={() => handleRemove(p.paper_id)}
                  className="shrink-0 rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-600"
                  aria-label="Remove"
                >
                  <Trash2 size={16} />
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="flex flex-col-reverse justify-between gap-3 sm:flex-row">
        <button className="btn-secondary" onClick={() => navigate('/')}>
          <ArrowLeft size={20} /> Back
        </button>
        <button className="btn-primary" onClick={handleContinue} disabled={papers.length === 0 || uploading}>
          Start AI Marking ({papers.length} paper{papers.length !== 1 ? 's' : ''})
          <ArrowRight size={20} />
        </button>
      </div>
    </Layout>
  )
}
