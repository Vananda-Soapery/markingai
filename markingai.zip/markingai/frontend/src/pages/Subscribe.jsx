import { useLocation, useNavigate } from 'react-router-dom'
import { Lock, CheckCircle2, ArrowLeft } from 'lucide-react'
import Layout from '../components/Layout'

const BENEFITS = [
  'Unlimited AI-marked papers every month',
  'SA-SAMS ready Excel exports',
  'Class performance reports & intervention lists',
  'Priority support for setup and marking issues',
]

export default function Subscribe() {
  const navigate = useNavigate()
  const location = useLocation()
  const returnTo = location.state?.returnTo || '/'

  return (
    <Layout>
      <div className="mx-auto max-w-md text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-100 text-brand-600">
          <Lock size={28} />
        </div>
        <h2 className="text-2xl font-bold text-slate-900">Subscribe to keep marking</h2>
        <p className="mt-2 text-slate-500">
          Your trial or subscription has ended. Subscribe to continue using AI marking and exports.
        </p>

        <div className="card mt-6 text-left">
          <ul className="space-y-3">
            {BENEFITS.map((b) => (
              <li key={b} className="flex items-start gap-2 text-sm text-slate-700">
                <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-green-600" />
                {b}
              </li>
            ))}
          </ul>
        </div>

        <button
          className="btn-primary mt-6 w-full"
          onClick={() => {
            // Wire this up to your real checkout flow (Stripe Checkout, etc.)
            // once billing is integrated.
            window.location.href = '/billing/checkout'
          }}
        >
          View subscription plans
        </button>

        <button className="btn-secondary mt-3 w-full" onClick={() => navigate(returnTo)}>
          <ArrowLeft size={18} /> Back
        </button>
      </div>
    </Layout>
  )
}
