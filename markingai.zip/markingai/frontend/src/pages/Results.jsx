import { useEffect, useState, useCallback } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
  Download, RefreshCw, Edit3, Save, X, PlusCircle,
  TrendingUp, TrendingDown, Users, AlertTriangle, CheckCircle2,
} from 'lucide-react'
import Layout from '../components/Layout'
import StepIndicator from '../components/StepIndicator'
import ErrorBanner from '../components/ErrorBanner'
import {
  sessionsApi, getErrorMessage, downloadBlobResponse, isSubscriptionRequiredError,
} from '../api/client'

const STATUS_BADGE = {
  done: 'bg-green-100 text-green-700',
  needs_review: 'bg-amber-100 text-amber-700',
  failed: 'bg-red-100 text-red-700',
  processing: 'bg-blue-100 text-blue-700',
  pending: 'bg-slate-100 text-slate-500',
}

const STATUS_LABEL = {
  done: 'Marked',
  needs_review: 'Needs review',
  failed: 'Failed',
  processing: 'Processing',
  pending: 'Pending',
}

function scoreColor(pct) {
  if (pct == null) return 'text-slate-400'
  if (pct < 40) return 'text-red-600'
  if (pct < 60) return 'text-amber-600'
  return 'text-green-600'
}

export default function Results() {
  const { sessionId } = useParams()
  const navigate = useNavigate()

  const [sessionInfo, setSessionInfo] = useState(null)
  const [papers, setPapers] = useState([])
  const [summary, setSummary] = useState(null)
  const [error, setError] = useState(null)
  const [editingId, setEditingId] = useState(null)
  const [editDraft, setEditDraft] = useState({})
  const [retrying, setRetrying] = useState({})
  const [downloading, setDownloading] = useState({ sasams: false, report: false })

  const loadResults = useCallback(async () => {
    try {
      const { data } = await sessionsApi.getResults(sessionId)
      setSessionInfo(data)
      setPapers(data.papers)
      const { data: summaryData } = await sessionsApi.getSummary(sessionId)
      setSummary(summaryData)
    } catch (e) {
      setError(getErrorMessage(e))
    }
  }, [sessionId])

  useEffect(() => {
    loadResults()
  }, [loadResults])

  const startEdit = (paper) => {
    setEditingId(paper.paper_id)
    setEditDraft({
      student_name: paper.matched_class_list_name || paper.student_name || '',
      total_marks_awarded: paper.total_marks_awarded ?? '',
      ai_comment: paper.ai_comment || '',
    })
  }

  const saveEdit = async (paperId) => {
    try {
      const { data: updated } = await sessionsApi.editPaper(sessionId, paperId, {
        student_name: editDraft.student_name,
        matched_class_list_name: editDraft.student_name,
        total_marks_awarded: editDraft.total_marks_awarded,
        ai_comment: editDraft.ai_comment,
      })
      setPapers((prev) => prev.map((p) => (p.paper_id === paperId ? updated : p)))
      setEditingId(null)
      loadResults()
    } catch (e) {
      setError(getErrorMessage(e))
    }
  }

  const retryPaper = async (paperId) => {
    setRetrying((r) => ({ ...r, [paperId]: true }))
    try {
      await sessionsApi.retryPaper(sessionId, paperId)
      await loadResults()
    } catch (e) {
      setError(getErrorMessage(e))
    } finally {
      setRetrying((r) => ({ ...r, [paperId]: false }))
    }
  }

  const handleDownload = async (kind) => {
    setDownloading((d) => ({ ...d, [kind]: true }))
    setError(null)
    try {
      const response = kind === 'sasams'
        ? await sessionsApi.exportSasams(sessionId)
        : await sessionsApi.exportReport(sessionId)
      const fallbackName = kind === 'sasams' ? 'SASAMS_Import.xlsx' : 'Class_Report.xlsx'
      downloadBlobResponse(response, fallbackName)
    } catch (e) {
      if (isSubscriptionRequiredError(e)) {
        navigate('/subscribe', { state: { returnTo: `/results/${sessionId}` } })
        return
      }
      setError(getErrorMessage(e))
    } finally {
      setDownloading((d) => ({ ...d, [kind]: false }))
    }
  }

  const needsReviewCount = papers.filter((p) => p.status === 'needs_review' || p.status === 'failed').length

  return (
    <Layout>
      <StepIndicator currentStep={4} />

      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-slate-900 sm:text-3xl">Results are ready</h2>
        <p className="mt-1 text-slate-500">
          {sessionInfo ? `${sessionInfo.subject} · Grade ${sessionInfo.grade} · ${sessionInfo.test_name}` : ''}
        </p>
      </div>

      <ErrorBanner message={error} onDismiss={() => setError(null)} />

      {needsReviewCount > 0 && (
        <div className="mb-6 flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
          <AlertTriangle size={18} className="mt-0.5 shrink-0" />
          <p>
            <strong>{needsReviewCount}</strong> paper{needsReviewCount !== 1 ? 's need' : ' needs'} your review below (illegible,
            failed, or low-confidence AI reads). Please check these before exporting.
          </p>
        </div>
      )}

      {/* Summary stat cards */}
      {summary && (
        <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <StatCard icon={<Users size={18} />} label="Class average" value={`${summary.class_average_percentage}%`} />
          <StatCard icon={<TrendingUp size={18} className="text-green-600" />} label="Highest" value={`${summary.highest_percentage}%`} />
          <StatCard icon={<TrendingDown size={18} className="text-red-500" />} label="Lowest" value={`${summary.lowest_percentage}%`} />
          <StatCard icon={<CheckCircle2 size={18} className="text-brand-600" />} label="Graded" value={summary.total_students_graded} />
        </div>
      )}

      {/* Export buttons */}
      <div className="card mb-6 flex flex-col gap-3 sm:flex-row">
        <button
          onClick={() => handleDownload('sasams')}
          disabled={downloading.sasams}
          className="btn-primary flex-1"
        >
          <Download size={20} /> {downloading.sasams ? 'Preparing...' : 'Download SA-SAMS Excel'}
        </button>
        <button
          onClick={() => handleDownload('report')}
          disabled={downloading.report}
          className="btn-secondary flex-1"
        >
          <Download size={20} /> {downloading.report ? 'Preparing...' : 'Download Class Report'}
        </button>
      </div>

      {/* Results table */}
      <div className="card overflow-hidden !p-0">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead className="border-b border-slate-100 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-4 py-3">Student</th>
                <th className="px-4 py-3">File</th>
                <th className="px-4 py-3">Score</th>
                <th className="px-4 py-3">%</th>
                <th className="px-4 py-3">Comment</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {papers.map((p) => {
                const isEditing = editingId === p.paper_id
                const displayName = p.matched_class_list_name || p.student_name || '—'
                return (
                  <tr key={p.paper_id} className="align-top hover:bg-slate-50/60">
                    <td className="px-4 py-3">
                      {isEditing ? (
                        <input
                          className="w-full rounded-lg border border-slate-200 px-2 py-1 text-sm"
                          value={editDraft.student_name}
                          onChange={(e) => setEditDraft((d) => ({ ...d, student_name: e.target.value }))}
                        />
                      ) : (
                        <span className={`font-medium ${displayName === '—' ? 'text-slate-400 italic' : 'text-slate-800'}`}>
                          {displayName === '—' ? 'Unidentified' : displayName}
                        </span>
                      )}
                    </td>
                    <td className="max-w-[140px] truncate px-4 py-3 text-slate-500">{p.filename}</td>
                    <td className="px-4 py-3">
                      {isEditing ? (
                        <input
                          type="number"
                          className="w-20 rounded-lg border border-slate-200 px-2 py-1 text-sm"
                          value={editDraft.total_marks_awarded}
                          onChange={(e) => setEditDraft((d) => ({ ...d, total_marks_awarded: e.target.value }))}
                        />
                      ) : (
                        <span className="font-medium text-slate-700">
                          {p.total_marks_awarded ?? '—'} / {p.total_marks_possible ?? sessionInfo?.total_marks}
                        </span>
                      )}
                    </td>
                    <td className={`px-4 py-3 font-bold ${scoreColor(p.percentage)}`}>
                      {p.percentage != null ? `${p.percentage}%` : '—'}
                    </td>
                    <td className="max-w-xs px-4 py-3 text-slate-600">
                      {isEditing ? (
                        <textarea
                          className="w-full rounded-lg border border-slate-200 px-2 py-1 text-sm"
                          rows={2}
                          value={editDraft.ai_comment}
                          onChange={(e) => setEditDraft((d) => ({ ...d, ai_comment: e.target.value }))}
                        />
                      ) : (
                        <span className="line-clamp-2">{p.ai_comment || p.error_message || '—'}</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-block rounded-full px-2.5 py-1 text-xs font-semibold ${STATUS_BADGE[p.status] || STATUS_BADGE.pending}`}>
                        {STATUS_LABEL[p.status] || p.status}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      {isEditing ? (
                        <div className="flex gap-1">
                          <button onClick={() => saveEdit(p.paper_id)} className="rounded-lg p-1.5 text-green-600 hover:bg-green-50" aria-label="Save">
                            <Save size={16} />
                          </button>
                          <button onClick={() => setEditingId(null)} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100" aria-label="Cancel">
                            <X size={16} />
                          </button>
                        </div>
                      ) : (
                        <div className="flex gap-1">
                          <button onClick={() => startEdit(p)} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100" aria-label="Edit">
                            <Edit3 size={16} />
                          </button>
                          {(p.status === 'failed' || p.status === 'needs_review') && (
                            <button
                              onClick={() => retryPaper(p.paper_id)}
                              disabled={retrying[p.paper_id]}
                              className="rounded-lg p-1.5 text-brand-500 hover:bg-brand-50 disabled:opacity-50"
                              aria-label="Retry"
                            >
                              <RefreshCw size={16} className={retrying[p.paper_id] ? 'animate-spin' : ''} />
                            </button>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Intervention list */}
      {summary?.intervention_list?.length > 0 && (
        <div className="card mt-6">
          <h3 className="mb-3 flex items-center gap-2 font-semibold text-slate-800">
            <AlertTriangle size={18} className="text-red-500" /> Students needing intervention (below 40%)
          </h3>
          <ul className="divide-y divide-slate-100">
            {summary.intervention_list.map((s, i) => (
              <li key={i} className="py-2.5 text-sm">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-slate-700">{s.name}</span>
                  <span className="font-bold text-red-600">{s.percentage}%</span>
                </div>
                {s.comment && <p className="mt-0.5 text-xs text-slate-500">{s.comment}</p>}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-8 flex justify-center">
        <button className="btn-secondary" onClick={() => navigate('/')}>
          <PlusCircle size={20} /> Mark a New Test
        </button>
      </div>
    </Layout>
  )
}

function StatCard({ icon, label, value }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center">
      <div className="mb-1 flex items-center justify-center gap-1.5 text-slate-400">{icon}</div>
      <p className="text-xl font-bold text-slate-900">{value}</p>
      <p className="text-xs text-slate-500">{label}</p>
    </div>
  )
}
