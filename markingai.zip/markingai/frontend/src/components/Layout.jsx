import { GraduationCap } from 'lucide-react'

export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-brand-50/60 to-slate-50">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-4 sm:px-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-600 text-white">
            <GraduationCap size={22} />
          </div>
          <div>
            <h1 className="text-lg font-bold leading-tight text-slate-900">MarkingAI</h1>
            <p className="text-xs leading-tight text-slate-500">Automated marking for SA teachers</p>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-10">{children}</main>
      <footer className="mx-auto max-w-5xl px-4 py-6 text-center text-xs text-slate-400 sm:px-6">
        MarkingAI · Always review AI-marked papers before finalising results.
      </footer>
    </div>
  )
}
