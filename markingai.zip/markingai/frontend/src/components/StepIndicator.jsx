import { Check } from 'lucide-react'

const STEPS = [
  { number: 1, label: 'Test Setup' },
  { number: 2, label: 'Upload Papers' },
  { number: 3, label: 'AI Marking' },
  { number: 4, label: 'Results' },
]

export default function StepIndicator({ currentStep }) {
  return (
    <div className="mx-auto mb-8 flex max-w-2xl items-center justify-between px-2">
      {STEPS.map((step, idx) => {
        const isComplete = step.number < currentStep
        const isActive = step.number === currentStep
        return (
          <div key={step.number} className="flex flex-1 items-center">
            <div className="flex flex-col items-center gap-2">
              <div
                className={`step-pill ${
                  isComplete
                    ? 'bg-brand-600 text-white'
                    : isActive
                    ? 'bg-brand-100 text-brand-700 ring-2 ring-brand-600'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                {isComplete ? <Check size={18} /> : step.number}
              </div>
              <span
                className={`hidden text-xs font-medium sm:block ${
                  isActive ? 'text-brand-700' : isComplete ? 'text-slate-600' : 'text-slate-400'
                }`}
              >
                {step.label}
              </span>
            </div>
            {idx < STEPS.length - 1 && (
              <div className={`mx-2 h-1 flex-1 rounded-full ${isComplete ? 'bg-brand-600' : 'bg-slate-200'}`} />
            )}
          </div>
        )
      })}
    </div>
  )
}
