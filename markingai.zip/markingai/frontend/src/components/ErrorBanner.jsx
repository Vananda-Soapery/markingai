import { AlertTriangle, X } from 'lucide-react'

export default function ErrorBanner({ message, onDismiss }) {
  if (!message) return null
  return (
    <div className="mb-6 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 p-4 text-red-800">
      <AlertTriangle size={20} className="mt-0.5 shrink-0" />
      <p className="flex-1 text-sm font-medium">{message}</p>
      {onDismiss && (
        <button onClick={onDismiss} className="shrink-0 rounded-full p-1 hover:bg-red-100" aria-label="Dismiss">
          <X size={16} />
        </button>
      )}
    </div>
  )
}
