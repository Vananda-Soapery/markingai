import { useCallback, useRef, useState } from 'react'
import { UploadCloud, FileCheck2 } from 'lucide-react'

export default function DropZone({
  onFiles,
  accept,
  multiple = false,
  label,
  hint,
  compact = false,
  successFilename = null,
}) {
  const [isDragging, setIsDragging] = useState(false)
  const inputRef = useRef(null)

  const handleDrop = useCallback(
    (e) => {
      e.preventDefault()
      setIsDragging(false)
      const files = Array.from(e.dataTransfer.files || [])
      if (files.length) onFiles(multiple ? files : [files[0]])
    },
    [onFiles, multiple]
  )

  const handleChange = (e) => {
    const files = Array.from(e.target.files || [])
    if (files.length) onFiles(multiple ? files : [files[0]])
    e.target.value = '' // allow re-selecting the same file
  }

  return (
    <div
      onClick={() => inputRef.current?.click()}
      onDragOver={(e) => {
        e.preventDefault()
        setIsDragging(true)
      }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && inputRef.current?.click()}
      className={`cursor-pointer rounded-2xl border-2 border-dashed transition-colors ${
        compact ? 'p-5' : 'p-10'
      } text-center ${
        isDragging
          ? 'border-brand-500 bg-brand-50'
          : successFilename
          ? 'border-green-300 bg-green-50'
          : 'border-slate-300 bg-white hover:border-brand-400 hover:bg-brand-50/40'
      }`}
    >
      <input ref={inputRef} type="file" accept={accept} multiple={multiple} onChange={handleChange} className="hidden" />
      <div className="flex flex-col items-center gap-2">
        {successFilename ? (
          <>
            <FileCheck2 className="text-green-600" size={compact ? 28 : 36} />
            <p className="font-semibold text-green-700">{successFilename}</p>
            <p className="text-xs text-green-600">Tap to replace</p>
          </>
        ) : (
          <>
            <UploadCloud className={isDragging ? 'text-brand-600' : 'text-slate-400'} size={compact ? 28 : 36} />
            <p className="font-semibold text-slate-700">{label}</p>
            {hint && <p className="text-xs text-slate-400">{hint}</p>}
          </>
        )}
      </div>
    </div>
  )
}
