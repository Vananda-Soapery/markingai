import { Routes, Route } from 'react-router-dom'
import TestSetup from './pages/TestSetup'
import PaperUpload from './pages/PaperUpload'
import Processing from './pages/Processing'
import Results from './pages/Results'
import Subscribe from './pages/Subscribe'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<TestSetup />} />
      <Route path="/upload/:sessionId" element={<PaperUpload />} />
      <Route path="/processing/:sessionId" element={<Processing />} />
      <Route path="/results/:sessionId" element={<Results />} />
      <Route path="/subscribe" element={<Subscribe />} />
      <Route path="*" element={<TestSetup />} />
    </Routes>
  )
}
