import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api'
const TOKEN_STORAGE_KEY = 'markingai_api_token'

export const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 120000, // AI grading can take a while for large batches
})

// --- Auth token handling -------------------------------------------------
// The backend gates paid endpoints (AI marking, exports) behind a bearer
// token tied to the teacher's subscription. We keep it in localStorage so
// it survives refreshes, and attach it to every outgoing request.

export function setAuthToken(token) {
  if (token) {
    localStorage.setItem(TOKEN_STORAGE_KEY, token)
  } else {
    localStorage.removeItem(TOKEN_STORAGE_KEY)
  }
}

export function getAuthToken() {
  return localStorage.getItem(TOKEN_STORAGE_KEY)
}

api.interceptors.request.use((config) => {
  const token = getAuthToken()
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Extracts a friendly error message from an axios error.
export function getErrorMessage(error) {
  const detail = error?.response?.data?.detail
  if (detail && typeof detail === 'object' && detail.error === 'subscription_required') {
    return detail.message || 'An active subscription is required for this feature.'
  }
  if (typeof detail === 'string') {
    return detail
  }
  if (error?.message === 'Network Error') {
    return 'Could not reach the MarkingAI server. Please check your connection and that the backend is running.'
  }
  return error?.message || 'Something went wrong. Please try again.'
}

// True when a failed request was specifically a "please subscribe" block,
// so the UI can route to a paywall screen instead of a generic error banner.
export function isSubscriptionRequiredError(error) {
  return error?.response?.status === 402
}

export const sessionsApi = {
  create: (data) => {
    const form = new FormData()
    form.append('subject', data.subject)
    form.append('grade', data.grade)
    form.append('total_marks', data.totalMarks)
    form.append('test_name', data.testName || 'Test')
    return api.post('/sessions', form)
  },

  uploadMemo: (sessionId, file) => {
    const form = new FormData()
    form.append('file', file)
    return api.post(`/sessions/${sessionId}/memo`, form)
  },

  uploadClassList: (sessionId, file) => {
    const form = new FormData()
    form.append('file', file)
    return api.post(`/sessions/${sessionId}/class-list`, form)
  },

  get: (sessionId) => api.get(`/sessions/${sessionId}`),

  uploadPapers: (sessionId, files, onProgress) => {
    const form = new FormData()
    files.forEach((f) => form.append('files', f))
    return api.post(`/sessions/${sessionId}/papers`, form, {
      onUploadProgress: onProgress,
    })
  },

  listPapers: (sessionId) => api.get(`/sessions/${sessionId}/papers`),

  removePaper: (sessionId, paperId) => api.delete(`/sessions/${sessionId}/papers/${paperId}`),

  startProcessing: (sessionId) => api.post(`/sessions/${sessionId}/process`),

  getProgress: (sessionId) => api.get(`/sessions/${sessionId}/progress`),

  retryPaper: (sessionId, paperId) => api.post(`/sessions/${sessionId}/papers/${paperId}/retry`),

  getResults: (sessionId) => api.get(`/sessions/${sessionId}/results`),

  getSummary: (sessionId) => api.get(`/sessions/${sessionId}/summary`),

  editPaper: (sessionId, paperId, updates) => api.patch(`/sessions/${sessionId}/papers/${paperId}`, updates),

  // Exports are gated by subscription, so they must go through the
  // authenticated axios instance (not a plain <a href>, which can't attach
  // an Authorization header) and be saved client-side as a blob.
  exportSasams: (sessionId) =>
    api.get(`/sessions/${sessionId}/export/sasams`, { responseType: 'blob' }),

  exportReport: (sessionId) =>
    api.get(`/sessions/${sessionId}/export/report`, { responseType: 'blob' }),
}

// Triggers a browser "Save As" for a blob response, reading the filename
// from the Content-Disposition header when the backend sets one.
export function downloadBlobResponse(response, fallbackFilename) {
  const disposition = response.headers?.['content-disposition']
  let filename = fallbackFilename
  if (disposition) {
    const match = disposition.match(/filename="?([^"]+)"?/)
    if (match) filename = match[1]
  }
  const url = window.URL.createObjectURL(new Blob([response.data]))
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  link.remove()
  window.URL.revokeObjectURL(url)
}

export const healthApi = {
  check: () => api.get('/health'),
}
