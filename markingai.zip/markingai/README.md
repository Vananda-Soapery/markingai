# MarkingAI

AI-powered automated test paper marking for South African teachers. Upload a memo, upload scanned student papers, and get marked results, personalized feedback, and SA-SAMS-ready exports in minutes.

## Stack

- **Frontend:** React + Vite + Tailwind CSS
- **Backend:** Python FastAPI
- **AI:** OpenAI GPT-4o (Vision) — reads scanned handwritten/typed papers and marks against the memo
- **Exports:** openpyxl-generated Excel files (SA-SAMS import sheet + class performance report)

## Project structure

```
markingai/
  backend/
    app/
      main.py            # FastAPI app entrypoint
      config.py           # env-based settings
      schemas.py           # pydantic models
      store.py             # in-memory session store
      routers/
        setup.py           # Step 1: create session, upload memo & class list
        papers.py           # Step 2: batch paper upload
        processing.py       # Step 3: AI grading orchestration + progress polling
        results.py          # Step 4: results, edits, exports
      services/
        file_processing.py  # PDF/image conversion, memo & class list parsing
        grading.py           # GPT-4o Vision grading call + JSON parsing
        export.py            # Excel export builders
    requirements.txt
    .env.example
  frontend/
    src/
      pages/
        TestSetup.jsx        # Step 1
        PaperUpload.jsx       # Step 2
        Processing.jsx        # Step 3
        Results.jsx           # Step 4
      components/             # DropZone, StepIndicator, Layout, ErrorBanner
      api/client.js            # API wrapper
    package.json
    .env.example
```

## Setup

### 1. Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# Edit .env and set OPENAI_API_KEY=sk-...

uvicorn app.main:app --reload --port 8000
```

The API will be live at `http://localhost:8000`. Interactive docs at `http://localhost:8000/docs`.

### 2. Frontend

```bash
cd frontend
npm install
cp .env.example .env   # defaults are fine for local dev (uses Vite proxy)
npm run dev
```

Open `http://localhost:5173`.

## Environment variables

**backend/.env**

| Variable | Description |
|---|---|
| `OPENAI_API_KEY` | Your OpenAI API key (must have GPT-4o access) — **required** |
| `OPENAI_MODEL` | Model to use, default `gpt-4o` |
| `ALLOWED_ORIGINS` | Comma-separated list of allowed frontend origins for CORS |
| `MAX_CONCURRENT_GRADING` | How many papers to grade in parallel (default 3, tune to your OpenAI rate limit) |

**frontend/.env**

| Variable | Description |
|---|---|
| `VITE_API_BASE_URL` | Backend API base URL, default `/api` (proxied to `localhost:8000` in dev) |

## How it works

1. **Test Setup** — Teacher enters subject, grade, total marks, and uploads the memo (PDF) and optionally a class list (Excel/CSV) for name-matching.
2. **Batch Upload** — Teacher drags in all scanned papers at once (images or multi-page PDFs).
3. **AI Processing** — The backend loops through every paper, renders each page to an image, and sends it with the memo text to GPT-4o Vision, requesting a strict JSON response: student name, marks per question, total, and a personalized comment. This runs with limited concurrency so as not to hit OpenAI rate limits, and the frontend polls a `/progress` endpoint every 1.5s to show a live "Marking paper X of Y" bar.
4. **Results & Export** — Results appear in an editable table (teachers can correct AI misreads before export). Two one-click Excel downloads are provided: a SA-SAMS-ready import sheet, and a class performance report with the class average, hardest questions, and an intervention list of students below 40%.

## Production notes

- The current session store is **in-memory** — fine for a single-teacher-at-a-time deployment on a school server, but swap `app/store.py` for Redis or a database if you need multi-user concurrency or persistence across restarts.
- Uploaded files are stored under `backend/uploads/sessions/<session_id>/`. Add a cleanup job/cron if you want to purge old sessions.
- Set `ALLOWED_ORIGINS` to your real frontend domain before deploying.
- GPT-4o Vision costs scale with image size/count — the backend caps rendered pages at 2000px on the long edge to control cost while preserving legibility.
- Always have teachers review AI-marked papers (especially "Needs review" and "Failed" rows) before finalizing — this is built into the UI as an explicit warning banner.
