"""
Development-only helper endpoints for creating test users and API tokens.

This exists so the subscription-gating flow is testable end-to-end without
a real signup/billing system wired in yet. DO NOT ship this router to
production as-is — replace it with real signup + Stripe webhook handling
(see models_user.py:UserStore.update_subscription for the hook point) and
remove this file or gate it behind an admin-only check.
"""
from __future__ import annotations
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter
from pydantic import BaseModel

from app.models_user import user_store, SubscriptionStatus

router = APIRouter(prefix="/api/dev", tags=["dev-only"])


class CreateTestUserRequest(BaseModel):
    email: str
    subscription_status: SubscriptionStatus = SubscriptionStatus.ACTIVE
    days_until_expiry: int = 30  # negative values create an already-expired subscription


@router.post("/test-user")
async def create_test_user(payload: CreateTestUserRequest):
    """
    Creates a user with a chosen subscription state and returns their API
    token. Use this token as 'Authorization: Bearer <token>' when calling
    /process, /papers/{id}/retry, or /export/* endpoints.
    """
    expiry = datetime.now(timezone.utc) + timedelta(days=payload.days_until_expiry)
    user = user_store.create(
        email=payload.email,
        subscription_status=payload.subscription_status,
        subscription_expiry=expiry,
    )
    return {
        "user_id": user.user_id,
        "email": user.email,
        "api_token": user.api_token,
        "subscription_status": user.subscription_status,
        "subscription_expiry": user.subscription_expiry,
        "has_active_subscription": user.has_active_subscription(),
    }
