"""
User + subscription state.

This is intentionally minimal: an in-memory store keyed by API token, mirroring
the pattern used in store.py for sessions. Swap for a real database table once
you have persistent accounts (e.g. Postgres + Stripe webhooks updating these
same fields: subscription_status, subscription_expiry).
"""
from __future__ import annotations
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class SubscriptionStatus(str, Enum):
    ACTIVE = "active"
    TRIALING = "trialing"
    PAST_DUE = "past_due"
    CANCELED = "canceled"
    NONE = "none"  # never subscribed


# Statuses that grant access as long as the subscription hasn't expired.
# past_due / canceled / none never grant access, regardless of expiry date.
ACCESS_GRANTING_STATUSES = {SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING}


@dataclass
class User:
    user_id: str
    email: str
    api_token: str
    subscription_status: SubscriptionStatus = SubscriptionStatus.NONE
    subscription_expiry: Optional[datetime] = None  # always stored in UTC
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def has_active_subscription(self, now: Optional[datetime] = None) -> bool:
        """
        Single source of truth for whether this user may use paid features.
        - status must be active or trialing
        - expiry must be set and in the future (inclusive comparison would
          hide off-by-one bugs, so we compare with a precise UTC timestamp
          rather than a bare date)
        """
        if self.subscription_status not in ACCESS_GRANTING_STATUSES:
            return False
        if self.subscription_expiry is None:
            return False
        now = now or datetime.now(timezone.utc)
        return self.subscription_expiry > now


class UserStore:
    def __init__(self):
        self._users_by_token: dict[str, User] = {}
        self._lock = threading.Lock()

    def create(
        self,
        email: str,
        subscription_status: SubscriptionStatus = SubscriptionStatus.NONE,
        subscription_expiry: Optional[datetime] = None,
    ) -> User:
        with self._lock:
            user = User(
                user_id=str(uuid.uuid4()),
                email=email,
                api_token=str(uuid.uuid4()),
                subscription_status=subscription_status,
                subscription_expiry=subscription_expiry,
            )
            self._users_by_token[user.api_token] = user
            return user

    def get_by_token(self, token: str) -> Optional[User]:
        return self._users_by_token.get(token)

    def update_subscription(
        self,
        user_id: str,
        status: SubscriptionStatus,
        expiry: Optional[datetime],
    ) -> Optional[User]:
        """Called from a Stripe webhook handler (or similar) in a real deployment."""
        with self._lock:
            for user in self._users_by_token.values():
                if user.user_id == user_id:
                    user.subscription_status = status
                    user.subscription_expiry = expiry
                    return user
        return None


user_store = UserStore()
