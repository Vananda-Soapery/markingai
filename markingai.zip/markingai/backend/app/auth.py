"""
FastAPI dependencies for identifying the current user and gating paid
features behind an active subscription.

Usage in a router:

    from app.auth import require_active_subscription

    @router.post("/sessions/{session_id}/process")
    async def start_processing(session_id: str, user: User = Depends(require_active_subscription)):
        ...

This keeps the check strictly server-side: the frontend never decides
whether marking is allowed, it just gets a 402/403 and shows the paywall.
"""
from __future__ import annotations
from fastapi import Header, HTTPException, status
from app.models_user import user_store, User


async def get_current_user(authorization: str | None = Header(default=None)) -> User:
    """
    Resolves the bearer token in the Authorization header to a User.
    Expects: "Authorization: Bearer <api_token>"
    """
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or malformed Authorization header. Expected 'Bearer <token>'.",
        )

    token = authorization.split(" ", 1)[1].strip()
    user = user_store.get_by_token(token)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired API token. Please log in again.",
        )
    return user


async def require_active_subscription(
    authorization: str | None = Header(default=None),
) -> User:
    """
    Same as get_current_user, but additionally enforces that the user has
    an active (or trialing, non-expired) subscription. Use this on any
    endpoint that costs money to run (AI grading, exports).
    """
    user = await get_current_user(authorization)

    if not user.has_active_subscription():
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail={
                "error": "subscription_required",
                "message": "An active MarkingAI subscription is required to use this feature.",
                "subscription_status": user.subscription_status,
            },
        )

    return user
